﻿public enum Specialty{Java = 1, CSharp,  HTML, PHP, Unknown}
