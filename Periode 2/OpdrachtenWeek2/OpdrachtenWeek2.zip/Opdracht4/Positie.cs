﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Opdracht4
{
    class Positie
    {
        public int rij, kolom;
    }
}
