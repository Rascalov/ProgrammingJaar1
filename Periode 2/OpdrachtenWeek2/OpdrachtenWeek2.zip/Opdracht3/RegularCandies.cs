﻿public enum RegularCandies
{
    Jellybean=1, Lozenge, LemonDrop, Gum_Square, LollipopHead, Jujube_Cluster 
}