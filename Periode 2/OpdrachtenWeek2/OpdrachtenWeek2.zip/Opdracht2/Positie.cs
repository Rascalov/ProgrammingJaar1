﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Opdracht2
{
    class Positie
    {
        public int rij, kolom;
    }
}
