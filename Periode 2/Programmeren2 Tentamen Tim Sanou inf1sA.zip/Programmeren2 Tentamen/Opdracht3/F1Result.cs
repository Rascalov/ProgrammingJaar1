﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Opdracht3
{
    class F1Result
    {
        public int RaceNummer;
        public int Ranking;
        public string Coureur;
        public string Team;
        public int StartPositie;
    }
}
